const express = require("express");
const app = express();
const path = require("path");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();

const dbService = require("./dbService");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Agar bisa akses file statis dari direktori client
app.use(express.static(path.join(__dirname, "..", "client")));

// Akses Bootstrap
app.get("/css/bootstrap.css", (req, res) => {
  res.sendFile(__dirname + "/node_modules/bootstrap/dist/css/bootstrap.css");
});
app.get("/js/bootstrap.js", (req, res) => {
  res.sendFile(__dirname + "/node_modules/bootstrap/dist/js/bootstrap.js");
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "client", "index.html"));
});

app.set("views", path.join(__dirname, "..", "client", "views"));
app.set("view engine", "ejs");

// USER
// read user
app.get("/users", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllUsers()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("users/UsersIndex", { users: data });
    })
    .catch((err) => {
      console.log(err);
      res.render("users/UsersIndex", { users: [] });
    });
});

// create user
app.get("/users/insert", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllUsers()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("users/UsersInsert");
    })
    .catch((err) => {
      console.log(err);
      res.render("users/UsersInsert");
    });
});

// insert user
app.post("/users/insert", (req, res) => {
  const { nama, username, password, kontak, role } = req.body;
  const db = dbService.getDbServiceInstance();

  db.insertNewUsers(nama, username, password, kontak, role)
    .then((insertedData) => {
      if (insertedData) {
        res.redirect("/users");
      } else {
        res.status(500).send("gagal!");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("error");
    });
});

// edit user
app.get("/users/edit/:id", (req, res) => {
  const { id } = req.params;
  const db = dbService.getDbServiceInstance();

  db.getUsersById(id)
    .then((users) => {
      if (users) {
        res.render("users/UsersUpdate", { users });
      } else {
        res.status(404).send("error");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("Errorr");
    });
});

// update user
app.post("/users/update/:id", (req, res) => {
  const { id } = req.params;
  const { nama, username, kontak, role } = req.body;
  const db = dbService.getDbServiceInstance();

  db.updateUsersById(id, nama, username, kontak, role)
    .then(res.redirect("/users"))
    .catch((err) => {
      console.log(err);
      res.status(500).send("Error");
    });
});

// delete user
app.post("/users/delete/:id", (req, res) => {
  const { id } = req.params;
  const db = dbService.getDbServiceInstance();

  const result = db.deleteUsersById(id);

  result.then(res.redirect("/users")).catch((err) => console.log(err));
});

// VENDOR
// read user
app.get("/vendor", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllVendor()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("vendor/VendorIndex", { vendors: data });
    })
    .catch((err) => {
      console.log(err);
      res.render("vendor/VendorIndex", { vendors: [] });
    });
});

// create user
app.get("/vendor/insert", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllVendor()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("vendor/VendorInsert");
    })
    .catch((err) => {
      console.log(err);
      res.render("vendor/VendorInsert");
    });
});

// insert user
app.post("/vendor/insert", (req, res) => {
  const { nama, pegawai, kontak, alamat } = req.body;
  const db = dbService.getDbServiceInstance();

  db.insertNewVendor(nama, pegawai, kontak, alamat)
    .then((insertedData) => {
      if (insertedData) {
        res.redirect("/vendor");
      } else {
        res.status(500).send("gagal!");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("error");
    });
});

// edit user
app.get("/vendor/edit/:id", (req, res) => {
  const { id } = req.params;
  const db = dbService.getDbServiceInstance();

  db.getVendorById(id)
    .then((vendors) => {
      if (vendors) {
        res.render("vendor/VendorUpdate", { vendors });
      } else {
        res.status(404).send("error");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("Errorr");
    });
});

// update user
app.post("/vendor/update/:id", (req, res) => {
  const { id } = req.params;
  const { nama, pegawai, kontak, alamat } = req.body;
  const db = dbService.getDbServiceInstance();

  db.updateVendorById(id, nama, pegawai, kontak, alamat)
    .then(res.redirect("/vendor"))
    .catch((err) => {
      console.log(err);
      res.status(500).send("Error");
    });
});

// delete user
app.post("/vendor/delete/:id", (req, res) => {
  const { id } = req.params;
  const db = dbService.getDbServiceInstance();

  const result = db.deleteVendorById(id);

  result.then(res.redirect("/vendor")).catch((err) => console.log(err));
});

// Provinsi
// read provinsi
app.get("/provinsi", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllProvinsi()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("provinsi/ProvinsiIndex", { provinsis: data });
    })
    .catch((err) => {
      console.log(err);
      res.render("provinsi/ProvinsiIndex", { provinsis: [] });
    });
});

// create provinsi
app.get("/provinsi/insert", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllProvinsi()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("provinsi/ProvinsiInsert");
    })
    .catch((err) => {
      console.log(err);
      res.render("provinsi/ProvinsiInsert");
    });
});

// insert provinsi
app.post("/provinsi/insert", (req, res) => {
  const { kode_provinsi, nama_provinsi } = req.body;
  const db = dbService.getDbServiceInstance();

  db.insertNewProvinsi( kode_provinsi, nama_provinsi )
    .then((insertedData) => {
      if (insertedData) {
        res.redirect("/provinsi");
      } else {
        res.status(500).send("gagal!");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("error");
    });
});

// edit provinsi
app.get("/provinsi/edit/:id", (req, res) => {
  const { id_provinsi } = req.params;
  const db = dbService.getDbServiceInstance();

  db.getProvinsiById(id_provinsi)
    .then((provinsis) => {
      if (provinsis) {
        res.render("provinsi/ProvinsiUpdate", { provinsis });
      } else {
        res.status(404).send("error");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("Errorr");
    });
});

// update provinsi
app.post("/provinsi/update/:id", (req, res) => {
  const { id_provinsi } = req.params;
  const { kode_provinsi, nama_provinsi } = req.body;
  const db = dbService.getDbServiceInstance();

  db.updateProvinsiById(id_provinsi, kode_provinsi, nama_provinsi)
    .then(res.redirect("/provinsi"))
    .catch((err) => {
      console.log(err);
      res.status(500).send("Error");
    });
});

// delete provinsi
app.post("/provinsi/delete/:id", (req, res) => {
  const { id_provinsi} = req.params;
  const db = dbService.getDbServiceInstance();

  const result = db.deleteProvinsiById(id_provinsi);

  result.then(res.redirect("/provinsi")).catch((err) => console.log(err));
});

//Biaya
// read biaya
app.get("/biaya", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllBiaya()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("biaya/BiayaIndex", { biayas: data });
    })
    .catch((err) => {
      console.log(err);
      res.render("biaya/BiayaIndex", { biayas: [] });
    });
});

// create provinsi
app.get("/biaya/insert", (req, res) => {
  const db = dbService.getDbServiceInstance();

  db.getAllBiaya()
    .then((data) => {
      if (!Array.isArray(data)) {
        console.log("Error:", data);
        data = [];
      }
      res.render("biaya/BiayaInsert");
    })
    .catch((err) => {
      console.log(err);
      res.render("biaya/BiayaInsert");
    });
});

// insert biaya
app.post("/biaya/insert", (req, res) => {
  const { jenis_pengiriman, berat_min, berat_max, biaya } = req.body;
  const db = dbService.getDbServiceInstance();

  db.insertNewBiaya( jenis_pengiriman, berat_min, berat_max, biaya )
    .then((insertedData) => {
      if (insertedData) {
        res.redirect("/biaya");
      } else {
        res.status(500).send("gagal!");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("error");
    });
});

// edit biaya
app.get("/biaya/edit/:id", (req, res) => {
  const { id } = req.params;
  const db = dbService.getDbServiceInstance();

  db.getBiayaById(id)
    .then((biayas) => {
      if (biayas) {
        res.render("biaya/BiayaUpdate", { biayas });
      } else {
        res.status(404).send("error");
      }
    })
    .catch((err) => {
      console.log(err);
      res.status(500).send("Errorr");
    });
});

// update biaya
app.post("/biaya/update/:id", (req, res) => {
  const { id } = req.params;
  const { jenis_pengiriman, berat_min, berat_max, biaya } = req.body;
  const db = dbService.getDbServiceInstance();

  db.updateBiayaById(id, jenis_pengiriman, berat_min, berat_max, biaya)
    .then(res.redirect("/biaya"))
    .catch((err) => {
      console.log(err);
      res.status(500).send("Error");
    });
});

// delete biaya
app.post("/biaya/delete/:id", (req, res) => {
  const { id } = req.params;
  const db = dbService.getDbServiceInstance();

  const result = db.deleteBiayaById(id);

  result.then(res.redirect("/biaya")).catch((err) => console.log(err));
});


app.listen(process.env.PORT, () => console.log("APP IS RUNNING"));
