const mysql = require("mysql");
const dotenv = require("dotenv");
dotenv.config();
let instance = null;

const connection = mysql.createConnection({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
  port: process.env.DB_PORT,
});

connection.connect((err) => {
  if (err) {
    console.log(err.message);
  }
  console.log("db " + connection.state);
});

class DbService {
  static getDbServiceInstance() {
    return instance ? instance : new DbService();
  }

  // Users Methods
  async getAllUsers() {
    try {
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM users;";

        connection.query(query, (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return [];
    }
  }

  async insertNewUsers(nama, username, password, kontak, role) {
    try {
      const insertId = await new Promise((resolve, reject) => {
        const query = "INSERT INTO users (nama, username, password, kontak, role) VALUES (?,?,?,?,?);";
        connection.query(query, [nama, username, password, kontak, role], (err, result) => {
          if (err) {
            reject(new Error(err.message));
          } else {
            resolve(result.insertId);
          }
        });
      });
      return {
        id: insertId,
        nama: nama,
        username: username,
        password: password,
        kontak: kontak,
        role: role
      };
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async getUsersById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM users WHERE id_user = ?";

        connection.query(query, [id], (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results[0]);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async updateUsersById(id, nama, username, kontak, role) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        // const query = "UPDATE users SET nama = ?, username = ?, kontak = ?, role = ? WHERE id_user = ?;";
        const query = "UPDATE users SET nama = ?, username = ?, kontak = ?, role = ? WHERE id_user = ?;"

        connection.query(query, [nama, username, kontak, role, id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  async deleteUsersById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "DELETE FROM users WHERE id_user = ?;";

        connection.query(query, [id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }


  // Vendor Methods
  async getAllVendor() {
    try {
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM vendor;";

        connection.query(query, (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return [];
    }
  }

  async insertNewVendor(nama, pegawai, kontak, alamat) {
    try {
      const insertId = await new Promise((resolve, reject) => {
        const query = "INSERT INTO vendor (nama, pegawai, kontak, alamat) VALUES (?,?,?,?);";
        connection.query(query, [nama, pegawai, kontak, alamat], (err, result) => {
          if (err) {
            reject(new Error(err.message));
          } else {
            resolve(result.insertId);
          }
        });
      });
      return {
        id: insertId,
        nama: nama,
        pegawai: pegawai,
        kontak: kontak,
        alamat: alamat,
      };
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async getVendorById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM vendor WHERE id_vendor = ?";

        connection.query(query, [id], (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results[0]);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async updateVendorById(id, nama, pegawai, kontak, alamat) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "UPDATE vendor SET nama = ?, pegawai = ?, kontak = ?, alamat = ? WHERE id_vendor = ?;"

        connection.query(query, [nama, pegawai, kontak, alamat, id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  async deleteVendorById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "DELETE FROM vendor WHERE id_vendor = ?;";

        connection.query(query, [id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

   // Provinsi Methods
   async getAllProvinsi() {
    try {
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM provinsi;";

        connection.query(query, (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return [];
    }
  }

  async insertNewProvinsi(kode_provinsi, nama_provinsi) {
    try {
      const insertId = await new Promise((resolve, reject) => {
        const query = "INSERT INTO provinsi (kode_provinsi, nama_provinsi) VALUES (?,?);";
        connection.query(query, [kode_provinsi, nama_provinsi], (err, result) => {
          if (err) {
            reject(new Error(err.message));
          } else {
            resolve(result.insertId);
          }
        });
      });
      return {
        id: insertId,
        kode_provinsi: kode_provinsi,
        nama_provinsi: nama_provinsi,
      };
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async getProvinsiById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM provinsi WHERE id_provinsi = ?";

        connection.query(query, [id], (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results[0]);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async updateProvinsiById(id, kode_provinsi, nama_provinsi) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "UPDATE provinsi SET kode_provinsi = ?, nama_provinsi = ? WHERE id_provinsi = ?;"

        connection.query(query, [kode_provinsi, nama_provinsi, id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  async deleteProvinsiById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "DELETE FROM provinsi WHERE id_provinsi = ?;";

        connection.query(query, [id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  //Biaya Method
   async getAllBiaya() {
    try {
      const response = await new Promise((resolve, reject) => {
        const query = "SELECT * FROM biaya;";

        connection.query(query, (err, results) => {
          if (err) reject(new Error(err.message));
          resolve(results);
        });
      });
      return response;
    } catch (error) {
      console.log(error);
      return [];
    }
  }

  async insertNewBiaya(jenis_pengiriman, berat_min, berat_max, biaya) {
    try {
      const insertId = await new Promise((resolve, reject) => {
        const query = "INSERT INTO biaya (jenis_pengiriman, berat_min, berat_max, biaya) VALUES (?,?,?,?);";
        connection.query(query, [jenis_pengiriman, berat_min, berat_max, biaya], (err, result) => {
          if (err) {
            reject(new Error(err.message));
          } else {
            resolve(result.insertId);
          }
        });
      });
      return {
        id: insertId,
        jenis_pengiriman: jenis_pengiriman,
        berat_min: berat_min,
        berat_max: berat_max,
        biaya: biaya
      };
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  async getBiayaById(id) {
    try {
        id = parseInt(id, 10);
        const response = await new Promise((resolve, reject) => {
            const query = "SELECT * FROM biaya WHERE id_biaya = ?";

            connection.query(query, [id], (err, results) => {
                if (err) {
                    return reject(new Error(err.message));
                }
                if (!results || results.length === 0) {
                    return resolve(null); // No results found
                }
                resolve(results[0]);
            });
        });
        return response;
    } catch (error) {
        console.log(error);
        return null;
    }
}


  async updateBiayaById(id, jenis_pengiriman, berat_min, berat_max, biaya) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "UPDATE biaya SET jenis_pengiriman = ?, berat_min = ?, berat_max = ?, biaya = ? WHERE id_biaya = ?;"

        connection.query(query, [jenis_pengiriman, berat_min, berat_max, biaya, id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  async deleteBiayaById(id) {
    try {
      id = parseInt(id, 10);
      const response = await new Promise((resolve, reject) => {
        const query = "DELETE FROM biaya WHERE id_biaya = ?;";

        connection.query(query, [id], (err, result) => {
          if (err) reject(new Error(err.message));
          resolve(result);
        });
      });
      return response === 1;
    } catch (error) {
      console.log(error);
      return false;
    }
  }
}

module.exports = DbService;
